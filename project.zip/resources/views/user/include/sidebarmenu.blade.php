
<aside>
    <div id="sidebar"  class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
            <li>
                <a class="active" href="{{ route('home') }}">
                    <i class="fa fa-dashboard"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            


           
            <li class="sub-menu">
                <a href="javascript:;" >
                    <i class="fa fa-laptop"></i>
                    <span>Coupon Sales</span>
                </a>
                <ul class="sub">
                    <li><a  href="{{ route('salecoupon.index') }}">All Sales Coupons</a></li>
                    <li><a  href="{{ route('salecoupon.create') }}">Sales Coupon</a></li>
                </ul>
            </li>

            <li>
                <a class="active" href="{{ route('winners_coupon') }}">
                    <i class="fa fa-laptop"></i>
                    <span>Winners Coupon</span>
                </a>
            </li>

        </ul>
        <!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end