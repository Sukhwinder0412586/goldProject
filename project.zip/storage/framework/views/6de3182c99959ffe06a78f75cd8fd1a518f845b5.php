<?php $__env->startComponent('mail::message'); ?>
# Congratulations

You have won <?php echo e($data->amount); ?> of this <?php echo e($data->coupon); ?>.

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\gold\websites\resources\views/LuckydrawEmail.blade.php ENDPATH**/ ?>