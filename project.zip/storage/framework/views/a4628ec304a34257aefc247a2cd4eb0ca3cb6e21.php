

<div class="form-group <?php echo e($errors->has('voucher') ? 'has-error' : ''); ?>">
    <label for="quantity" class="col-md-2 control-label">Voucher</label>
    <div class="col-md-10">
        <input class="form-control" name="voucher" type="text" id="voucher" value="<?php echo e(old('voucher')); ?>" minlength="1" placeholder="Enter voucher here...">
    <?php echo $errors->first('voucher', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>


<?php /**PATH C:\xampp\htdocs\gold\websites\resources\views/admin/coupon_selections/form.blade.php ENDPATH**/ ?>