
<div class="form-group <?php echo e($errors->has('user_id') ? 'has-error' : ''); ?>">
    <label for="user_id" class="col-md-2 control-label">User</label>
    <div class="col-md-10">
        <select class="js-example-basic-single" id="user_id" name="user_id">
        	    <option value="" style="display: none;" <?php echo e(old('user_id', optional($distributorCoupon)->user_id ?: '') == '' ? 'selected' : ''); ?> disabled="" abled selected>Select user</option>
        	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <option value="<?php echo e($key); ?>" <?php echo e(old('user_id', optional($distributorCoupon)->user_id) == $key ? 'selected' : ''); ?>>
			    	<?php echo e($user); ?>

			    </option>      
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        
        <?php echo $errors->first('user_id', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('quantity') ? 'has-error' : ''); ?>">
    <label for="quantity" class="col-md-2 control-label">Quantity</label>
    <div class="col-md-10">
        <input class="form-control" name="quantity" type="text" id="quantity" value="<?php echo e(old('quantity', optional($distributorCoupon)->quantity)); ?>" minlength="1" placeholder="Enter quantity here...">
        <?php echo $errors->first('quantity', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>

<?php /**PATH C:\xampp\htdocs\gold\websites\resources\views/admin/distributor_coupons/form.blade.php ENDPATH**/ ?>