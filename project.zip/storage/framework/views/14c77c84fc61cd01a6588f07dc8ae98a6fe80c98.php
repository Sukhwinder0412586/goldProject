
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Admin Login</title>

    <link href="<?php echo e(asset('ad_asset/css/3d-falling-leaves.css')); ?>" rel="stylesheet">
    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('ad_asset/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('ad_asset/css/bootstrap-reset.css')); ?>" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo e(asset('public/assets/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('ad_asset/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('ad_asset/css/style-responsive.css')); ?>" rel="stylesheet" />

    <script src="ad_asset/js/3d-falling-leaves.min"></script>
    <script src="ad_asset/js/3d-falling-leaves.js"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>

  <body class="login-body main-bg">
  <script>        jQuery(document).octoberLeaves() </script>

<div class="jquery-script-center">

</div>

    <div class="container">
		<?php if(Session::has('error')): ?>
			<?php echo e(Session::get('error')); ?>

		<?php endif; ?>
      <form class="form-signin" method="post" action="<?php echo e(route('login')); ?>">
        <?php echo e(csrf_field()); ?>

        <h2 class="form-signin-heading">sign in now</h2>
        <div class="login-wrap">
            <input type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="<?php echo e(__('E-Mail Address')); ?>" name="email" value="<?php echo e(old('email')); ?>">
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            <input type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Password" name="password">
            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            <button class="btn btn-lg btn-login btn-block" type="submit">Sign in</button>
            

        </div>

         

      </form>

    </div>



    <!-- js placed at the end of the document so the pages load faster -->
    <script src="/ad_asset/js/jquery.js"></script>
    <script src="/ad_asset/js/bootstrap.min.js"></script>


  </body>
</html>
<?php /**PATH C:\xampp\htdocs\gold\websites\resources\views/user/login.blade.php ENDPATH**/ ?>