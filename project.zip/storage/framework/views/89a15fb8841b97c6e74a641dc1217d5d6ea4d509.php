 <!-- js placed at the end of the document so the pages load faster -->
<script src="/ad_asset/js/jquery.js"></script>
<script src="/ad_asset/js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="/ad_asset/js/bootstrap.bundle.min.js"></script>
<script class="include" type="text/javascript" src="/ad_asset/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="/ad_asset/js/jquery.scrollTo.min.js"></script>
<script src="/ad_asset/js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="/ad_asset/assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="/ad_asset/assets/data-tables/DT_bootstrap.js"></script>
<script src="/ad_asset/js/respond.min.js" ></script>

<!--right slidebar-->
<script src="/ad_asset/js/slidebars.min.js"></script>

      
<!--common script for all pages-->
<script src="/ad_asset/js/common-scripts.js"></script>


<script type="text/javascript" src="/ad_asset/assets/select2/js/select2.min.js"></script>


<script src="/axios.js"></script>
<!--script for this page--><?php /**PATH C:\xampp\htdocs\gold\websites\resources\views/user/include/js.blade.php ENDPATH**/ ?>