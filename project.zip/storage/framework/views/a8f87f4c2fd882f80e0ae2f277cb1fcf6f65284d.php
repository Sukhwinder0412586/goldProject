<?php $__env->startSection('content'); ?>

    <?php if(Session::has('success_message')): ?>
        <div class="alert alert-success">
            <span class="glyphicon glyphicon-ok"></span>
            <?php echo session('success_message'); ?>


            <button type="button" class="close" data-dismiss="alert" aria-label="close">
                <span aria-hidden="true">&times;</span>
            </button>

        </div>
    <?php endif; ?>

    <div class="card">

        <header class="card-header clearfix">

            <div class="pull-left">
                <h4>Customers</h4>
            </div>

            <div class="btn-group btn-group-sm pull-right" role="group">
                <a href="<?php echo e(route('salecoupon.create')); ?>" class="btn btn-success" title="Create New Faq">
                    <i class="fa fa-plus-square" aria-hidden="true"></i>
                </a>
            </div>

        </header>
        
        <?php if(count($customers) == 0): ?>
            <div class="card-body text-center">
                <h6>No Customers Available.</h6>
            </div>
        <?php else: ?>
        <div class="card-body">
            <div class="adv-table">

                <table class="display table table-bordered table-striped" id="dynamic-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Phone Number</th>
                            <th>Quantity </th>
                            <th>Distributor </th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($customer->name); ?></td>
                            <td><?php echo $customer->number; ?></td>
                            <td><?php echo e($customer->quantity); ?></td>
                            <td><?php echo e(Auth::user()->name); ?></td>
                            <td>
                                <a href="<?php echo e(route('saleDownloadPdf',['name'=>$customer->name,'id'=>$customer->id])); ?>">Download PDF</a>
                            </td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>

        <?php endif; ?>
    
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript" language="javascript" src="/ad_asset/assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="/ad_asset/assets/data-tables/DT_bootstrap.js"></script>
<!--dynamic table initialization -->
<script src="/ad_asset/js/dynamic_table_init.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gold\websites\resources\views/user/saleCoupon/index.blade.php ENDPATH**/ ?>