
<aside>
    <div id="sidebar"  class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
            <li>
                <a class="active" href="<?php echo e(route('home')); ?>">
                    <i class="fa fa-dashboard"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            


           
            <li class="sub-menu">
                <a href="javascript:;" >
                    <i class="fa fa-laptop"></i>
                    <span>Coupon Sales</span>
                </a>
                <ul class="sub">
                    <li><a  href="<?php echo e(route('salecoupon.index')); ?>">All Sales Coupons</a></li>
                    <li><a  href="<?php echo e(route('salecoupon.create')); ?>">Sales Coupon</a></li>
                </ul>
            </li>

            <li>
                <a class="active" href="<?php echo e(route('winners_coupon')); ?>">
                    <i class="fa fa-laptop"></i>
                    <span>Winners Coupon</span>
                </a>
            </li>

        </ul>
        <!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end<?php /**PATH C:\xampp\htdocs\gold\websites\resources\views/user/include/sidebarmenu.blade.php ENDPATH**/ ?>