
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Admin Login</title>

    <link href="<?php echo e(asset('ad_asset/css/snow.css')); ?>" rel="stylesheet">
    
    <!-- Bootstrap core CSS -->

    <link href="<?php echo e(asset('ad_asset/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('ad_asset/css/bootstrap-reset.css')); ?>" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo e(asset('public/assets/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('ad_asset/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('ad_asset/css/style-responsive.css')); ?>" rel="stylesheet" />

    
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
    <style>
        html, body {
            width: 100%;
            height: 100%;
            margin: 0;
        }
        body { background-color:#222; color:#fff;}
        h1 { margin:250px auto; text-align:center;}
        </style>
        
</head>

  <body class="login-body main-bg background" id="container" style="margin: 0px">
  <span class="hidden" id="snowflake"><img src="https://i.pinimg.com/originals/eb/e0/ba/ebe0bab5a16088b7f66a806a7f522b23.png" width="30px" alt=""></span>
 <div>
    <div class="container" id="logo">
		<?php if(Session::has('error')): ?>
			<?php echo e(Session::get('error')); ?>

		<?php endif; ?>
      <form class="form-signin" method="post">
      <?php echo e(csrf_field()); ?>

      <center><img src="/ad_asset/img/logo.png" width="200px"></center>
        <!-- <h2 class="form-signin-heading">sign in now</h2> -->
        <div class="login-wrap">
            <input type="text" class="form-control <?php if ($errors->has('user_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('user_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="User ID" name="user_id" value="<?php echo e(old('user_id')); ?>">
            <?php if ($errors->has('user_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('user_id'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            <input type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Password" name="password">
            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            <button class="btn btn-lg btn-login btn-block" type="submit">Sign in</button>
            

        </div>

          <!-- Modal -->
          <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
              <div class="modal-dialog">
                  <div class="modal-content">
                      <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                          <h4 class="modal-title">Forgot Password ?</h4>
                      </div>
                      <div class="modal-body">
                          <p>Enter your e-mail address below to reset your password.</p>
                          <input type="text" name="email" placeholder="Email" autocomplete="off" class="form-control placeholder-no-fix">

                      </div>
                      <div class="modal-footer">
                          <button data-dismiss="modal" class="btn btn-default" type="button">Cancel</button>
                          <button class="btn btn-success" type="button">Submit</button>
                      </div>
                  </div>
              </div>
          </div>
          <!-- modal -->

      </form>

    </div>
</div>


    <!-- js placed at the end of the document so the pages load faster -->
    <script src="/ad_asset/js/jquery.js"></script>
    <script src="/ad_asset/js/bootstrap.min.js"></script>
    <script src="/ad_asset/js/snow.js"></script>


  </body>
</html>
<?php /**PATH C:\xampp\htdocs\gold\websites\resources\views/admin/login.blade.php ENDPATH**/ ?>