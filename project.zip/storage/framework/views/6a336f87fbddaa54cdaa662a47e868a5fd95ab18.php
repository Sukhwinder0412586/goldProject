<?php $__env->startSection('content'); ?>

    <div class="card">

        <header class="card-header">
            
            <span class="pull-left">
                <h4>Create New Distributor Coupon</h4>
            </span>

            <div class="btn-group btn-group-sm pull-right" role="group">
                <a href="<?php echo e(route('distributor_coupon.distributor_coupons.index')); ?>" class="btn btn-primary" title="Show All Distributor Coupon">
                    <i class="fa fa-list" aria-hidden="true"></i>
                </a>
            </div>

        </header>

        <div class="card-body">
        
            <?php if($errors->any()): ?>
                <ul class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('distributor_coupon.distributor_coupons.create')); ?>" accept-charset="UTF-8" id="create_distributor_coupon_form" name="create_distributor_coupon_form" class="form-horizontal">
            <?php echo e(csrf_field()); ?>

            <?php echo $__env->make('admin.distributor_coupons.form', [
                                        'distributorCoupon' => null,
                                      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="form-group">
                    <div class="col-md-offset-2 col-md-10">
                        <input class="btn btn-primary" type="submit" value="Add">
                    </div>
                </div>

            </form>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="/ad_asset/assets/select2/js/select2.min.js"></script>
<script src="/ad_asset/js/advanced-form-components.js"></script>
<!--select2-->
<script type="text/javascript">

  $(document).ready(function () {
      $(".js-example-basic-single").select2();

      $(".js-example-basic-multiple").select2();
  });
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gold\websites\resources\views/admin/distributor_coupons/create.blade.php ENDPATH**/ ?>