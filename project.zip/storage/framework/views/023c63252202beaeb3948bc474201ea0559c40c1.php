
<div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
    <label for="question" class="col-md-2 control-label">Customer Name</label>
    <div class="col-md-10">
        <input class="form-control" name="name" type="text" value="<?php echo e(old('name', optional($Customer)->name)); ?>" minlength="1" placeholder="Enter customer Name here...">
        <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
    <label for="question" class="col-md-2 control-label">Phone Number</label>
    <div class="col-md-10">
        <input class="form-control" name="number" type="number" value="<?php echo e(old('number', optional($Customer)->number)); ?>" minlength="1" placeholder="Enter customer number here...">
        <?php echo $errors->first('email', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('quantity') ? 'has-error' : ''); ?>">
    <label for="quantity" class="col-md-2 control-label">Quantity</label>
    <div class="col-md-10">
        <input class="form-control" name="quantity" type="text" id="quantity"  minlength="1" placeholder="Enter quantity here...">
        <?php echo $errors->first('quantity', '<div class="invalid-feedback">:message</div>'); ?>

    </div>
</div>

<?php /**PATH C:\xampp\htdocs\gold\websites\resources\views/user/saleCoupon/form.blade.php ENDPATH**/ ?>