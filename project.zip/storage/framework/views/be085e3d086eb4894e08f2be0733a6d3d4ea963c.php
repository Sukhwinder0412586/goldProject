<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <link rel="shortcut icon" href="/ad_asset/img/favicon.html">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <?php echo $__env->make('admin.include.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>

  <body>
<style>
      .invalid-feedback{
        display: block;
        width: 100%;
        margin-top: .25rem;
        font-size: 80%;
        color: #dc3545;
      }
</style>
      <section id="container">
        <?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.include.sidebarmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <!--main content start-->
          <section id="main-content">
              <section class="wrapper">
                  <?php echo $__env->yieldContent('content'); ?>
              </section>
          </section>
          <!--main content end-->

         
      </section>
    <?php echo $__env->make('admin.include.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('js'); ?>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\gold\websites\resources\views/admin/layout/layout.blade.php ENDPATH**/ ?>