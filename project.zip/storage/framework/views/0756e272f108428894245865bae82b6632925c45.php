<!-- Bootstrap core CSS -->
<link href="/ad_asset/css/bootstrap.min.css" rel="stylesheet">
<link href="/ad_asset/css/bootstrap-reset.css" rel="stylesheet">
<!--external css-->
<link href="/ad_asset/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href="/ad_asset/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
<link rel="stylesheet" href="/ad_asset/css/owl.carousel.css" type="text/css">

<!--right slidebar-->
<link href="/ad_asset/css/slidebars.css" rel="stylesheet">

<!-- Custom styles for this template -->
<link href="/ad_asset/assets/advanced-datatable/media/css/demo_page.css" rel="stylesheet" />
<link href="/ad_asset/assets/advanced-datatable/media/css/demo_table.css" rel="stylesheet" media="print" />
<link rel="stylesheet" href="/ad_asset/assets/data-tables/DT_bootstrap.css" />
<link rel="stylesheet" type="text/css" href="/ad_asset/assets/select2/css/select2.min.css"/>

<link href="/ad_asset/css/style.css" rel="stylesheet">
<link href="/ad_asset/css/style-responsive.css" rel="stylesheet" /><?php /**PATH C:\xampp\htdocs\gold\websites\resources\views/admin/include/css.blade.php ENDPATH**/ ?>