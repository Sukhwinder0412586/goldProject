<?php $__env->startSection('content'); ?>

    <div class="card">
  
        <header class="card-header">

            <div class="pull-left">
                <h4><?php echo e(!empty($title) ? $title : 'Distributor Coupon'); ?></h4>
            </div>
            <div class="btn-group btn-group-sm pull-right" role="group">

                <a href="<?php echo e(route('distributor_coupon.distributor_coupons.index')); ?>" class="btn btn-primary" title="Show All Distributor Coupon">
                    <i class="fa fa-list" aria-hidden="true"></i>
                </a>

                <a href="<?php echo e(route('distributor_coupon.distributor_coupons.create')); ?>" class="btn btn-success" title="Create New Distributor Coupon">
                   <i class="fa fa-plus-square" aria-hidden="true"></i>
                </a>

            </div>
        </header>

        <div class="card-body">

            <?php if($errors->any()): ?>
                <ul class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('distributor_coupon.distributor_coupons.edit', $distributorCoupon->id )); ?>" id="edit_distributor_coupon_form" name="edit_distributor_coupon_form" accept-charset="UTF-8" class="form-horizontal">
            <?php echo e(csrf_field()); ?>

            <input name="_method" type="hidden" value="PUT">
            <?php echo $__env->make('admin.distributor_coupons.form', [
                                        'distributorCoupon' => $distributorCoupon,
                                      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="form-group">
                    <div class="col-md-offset-2 col-md-10">
                        <input class="btn btn-primary" type="submit" value="Update">
                    </div>
                </div>
            </form>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gold\websites\resources\views/admin/distributor_coupons/edit.blade.php ENDPATH**/ ?>