<?php $__env->startSection('content'); ?>

    <?php if(Session::has('success_message')): ?>
        <div class="alert alert-success">
            <span class="glyphicon glyphicon-ok"></span>
            <?php echo session('success_message'); ?>


            <button type="button" class="close" data-dismiss="alert" aria-label="close">
                <span aria-hidden="true">&times;</span>
            </button>

        </div>
    <?php endif; ?>

    <div class="card">

        <header class="card-header clearfix">

            <!-- <div class="pull-left">
                <h4>Confirmation</h4>
            </div> -->


        </header>
        
       
        <div class="card-body">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Confirmation</h3>
                </div>
                <div class="panel-body">
                    Customer : <?php echo e($data->customer->name); ?> <br>
                    Customer Phone Number : <?php echo e($data->customer->number); ?> <br>
                    Distributor : <?php echo e($data->distributor->name); ?> <br>
                    Distributor Email : <?php echo e($data->distributor->email); ?> <br>
                    Voucher : <?php echo e($data->coupon); ?>

                </div>
            </div>
        </div>
        <form method="POST" action="<?php echo e(route('coupon_transaction_save')); ?>" accept-charset="UTF-8" id="create_faq_form" name="create_faq_form" class="form-horizontal">
        <?php echo csrf_field(); ?>
        <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
            <label for="question" class="col-md-2 control-label">Enter Amount</label>
            <div class="col-md-10">
                <input class="form-control" name="amount" type="text" value="" minlength="1" placeholder="Enter amount  here...">
                <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

            </div>

            <input type="hidden" name="distributor_id" value="<?php echo e($data->distributor->id); ?>">
            <input type="hidden" name="cust_id" value="<?php echo e($data->customer->id); ?>">
            <input type="hidden" name="coupon" value="<?php echo e($data->coupon); ?>">

        </div>
                <div class="form-group">
                    <div class="col-md-offset-2 col-md-10">
                        <input class="btn btn-primary" type="submit" value="Send">
                    </div>
                </div>



    </form>
    
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gold\websites\resources\views/admin/coupon_selections/confirm_selection.blade.php ENDPATH**/ ?>